ALTER TABLE product ADD active BOOLEAN;
UPDATE product SET active = true;